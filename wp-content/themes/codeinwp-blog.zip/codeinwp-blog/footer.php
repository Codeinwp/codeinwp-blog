<?php include TEMPLATEPATH.'/functions/hroptions/hroptionsinc.php'; ?>
<footer>
		<div id="footer_center">
			<div class="footer_item">
				<div class="footer_logo"><img src="<?php bloginfo( 'template_url' ); ?>/images/footer-logo.png" alt=""></div>
				<div class="footer_contact">
					<div class="call"><span>Call us</span><br><?= $hr_phone_nr; ?></div>
					<div class="email"><span>Email us</span><br><?= $hr_e_mail; ?></div>
				</div><!--/footer_contact-->
				<div class="copyright">
				Developed by <a href="http://www.codeinwp.com" rel="nofollow">Codeinwp.com</a>  <br> 
				WordPress icon / logo is Copyright © WordPress.com</div>
			</div><!--/footer_item-->
			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer One') ) : ?>
			<?php endif; ?>
			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Two') ) : ?>
			<?php endif; ?>
		</div>
	</footer>
	<?php wp_footer(); ?>
</body>
</html>